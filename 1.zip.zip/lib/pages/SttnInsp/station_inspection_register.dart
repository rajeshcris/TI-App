import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:ti/commonutils/ti_utilities.dart';
import 'dart:convert';
import 'package:ti/model/SttnInspModels/station_inspection_registerModel.dart';
import 'Trn_Sgnl_Failure.dart';
import 'package:flutter/material.dart';
import 'package:ti/commonutils/commonUtilities.dart';

class station_inspection_register extends StatefulWidget {
  @override
  _station_inspection_registerState createState() =>
      _station_inspection_registerState();
}

class _station_inspection_registerState
    extends State<station_inspection_register> {
  station_inspection_registerModel station_inspection_registerMod =
      new station_inspection_registerModel([
    'Follow up Action  Recorded  on Previous Inspection by SM',
    'Noticed Irregularities Highlighted by TI',
    'Provision of separate Inspection Register for Officers and supervisors',
    'Acknowledgement of Inspection Report by All  Staff',
    'Last Page No.'
  ], [
    false,
    false,
    false,
    false,
    false
  ], '');
  @override
  Widget build(BuildContext context) {
    TextEditingController _rmrkController = TextEditingController();
    _rmrkController.text = station_inspection_registerMod.rmrks1;

    return GestureDetector(
      onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
      child: Scaffold(
        appBar: TiUtilities.tiAppBar(context, "Station Inspction Register"),
        body: SingleChildScrollView(
          reverse: true,
          child: Column(
            children: [
              ListView.builder(
                shrinkWrap: true,
                itemCount: station_inspection_registerMod.sList1.length,
                itemBuilder: (BuildContext context, int index) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 5.0, horizontal: 4.0),
                    child: Card(
                      child: ListTile(
                          onTap: () {
                            return FocusManager.instance.primaryFocus
                                ?.unfocus();
                            //CautionOrdRegModel.postData(data);
                          },
                          title: Text(
                              station_inspection_registerMod.sList1[index]),
                          trailing: Checkbox(
                            activeColor: Colors.teal,
                            value: station_inspection_registerMod.cList1[index],
                            onChanged: (value) => setState(() => this
                                .station_inspection_registerMod
                                .cList1[index] = value),
                          )),
                    ),
                  );
                },
              ),
              SizedBox(
                height: 2.0,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                    child: TextFormField(
                  controller: _rmrkController,
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp("[0-9a-zA-Z]"))
                  ],
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Remarks(if any)',

                    alignLabelWithHint: true,

                    //suffixIcon: Padding( padding: const EdgeInsets.fromLTRB(10, 20, 20, 90),
                    //  child: Icon(
                    //   Icons.speaker_notes_rounded,
                    //  color: Colors.teal,
                    //  ),
                    //          )
                  ),
                  maxLines: 5,
                )),
              ),
              Container(
                child: ButtonTheme(
                  minWidth: 200,
                  height: 50,
                  child: MaterialButton(
                    onPressed: () async {
                      _callSaveCautionOrdRegWebService(
                              station_inspection_registerMod)
                          .then((res) {
                        if (res == 'Record Successfully Saved.') {
                          print('Record Successfully Saved.');
                          CommonUtilities.showOKDialog(context, "Success!!")
                              .then((res1) {
                            Navigator.pushNamed(context, '/Safty_meet_reg');
                          });
                        } else {
                          print(
                              'Problem in Sign On. Please Contact to Supervisor');
                        }
                      });
                    },
                    textColor: Colors.white,
                    color: Colors.teal,
                    child: Column(
                      // Replace with a Row for horizontal icon + text
                      children: <Widget>[
                        Icon(Icons.save_outlined),
                        Text(
                          "Save & Next",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        )
                      ],
                    ),
                    shape: new RoundedRectangleBorder(
                      borderRadius: new BorderRadius.circular(30.0),
                    ),
                  ),
                ),
              )

              /*     Container(
                child: ButtonTheme(
                 // minWidth: width / 3,
                  child: MaterialButton(
                    onPressed: () async {

                      _callSaveCautionOrdRegWebService(
                             widget.cautionOrdMod)
                            .then((res) {
                          Navigator.of(context,
                              rootNavigator: true)
                              .pop();
                          if (res == 'Record Successfully Saved.') {
                            print('Record Successfully Saved.');
                              Navigator.of(context).pushNamedAndRemoveUntil(
                                  '/home',
                                      (Route<dynamic> route) => false);

                          } else {

                               print('Problem in Sign On. Please Contact to Supervisor');
                          }
                        });

                    },
                    textColor: Colors.white,
                    color: Colors.teal,
                    child: Text(
                      "Save",
                      style: TextStyle(
                           fontWeight: FontWeight.bold),
                    ),
                    shape: new RoundedRectangleBorder(
                      borderRadius: new BorderRadius.circular(30.0),
                    ),
                  ),
                ),
              )  */
            ],
          ),
        ),
        bottomNavigationBar: BottomAppBar(
          child: Row(
            children: <Widget>[
              Expanded(
                child: IconButton(
                    onPressed: () {},
                    icon: Icon(
                      Icons.camera_alt_outlined,
                      color: Colors.white,
                    )),
              ),
              Expanded(
                child: IconButton(
                    onPressed: () {},
                    icon: Icon(
                      Icons.image_outlined,
                      color: Colors.white,
                    )),
              ),
            ],
          ),
          color: Colors.teal,
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            Navigator.pushNamed(context, '/Safty_meet_reg');
          },
          child: Icon(
            Icons.add,
            color: Colors.white,
          ),
          backgroundColor: Colors.lime,
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      ),
    );
  }

  Future<String> _callSaveCautionOrdRegWebService(
      station_inspection_registerModel station_inspection_register) async {
    //log.d(alpa);
    print('Inside Callservuce');
    String urlInputString = json.encode(station_inspection_register.toJson());
    print("urlInputString:" + urlInputString);
    // var url =
    //    ChalakdalConstants.webServiceUrl + 'saveAlpColpFpAttributesRecord';
    //log.d("url = " + url);
    //log.d("urlInputString = " + urlInputString);
    Map<String, String> headerInput = {
      "Accept": "*/*",
      "Content-Type": "application/json"

      //"application/x-www-form-urlencoded"
    };

    // var data = await http.get(Uri.parse("http://172.16.4.58:8080/DemoService/webapi/demoservice/SttnInspPost"));

    /*  final response = await http.post(Uri.parse("http://172.16.4.58:8080/DemoService/webapi/demoservice/SttnInspPost"),
        headers: headerInput,
        body: urlInputString,
        encoding: Encoding.getByName("utf-8"));

   */

    //log.d("response code = " + response.statusCode.toString());
    //var jsonRes;
    //jsonRes = json.decode(response.body);

    //print('jsonRes' + response.body);
    //log.d("response code = " + response.statusCode.toString());
    /* if (response == null || response.statusCode != 200) {
      throw new Exception(
          'HTTP request failed, statusCode: ${response?.statusCode}');
    } else {
      log.d("json result----- = " + jsonRes.toString());
      return jsonRes['vosList'][0].toString();
    }  */
    return 'Record Successfully Saved.';
  }
}
