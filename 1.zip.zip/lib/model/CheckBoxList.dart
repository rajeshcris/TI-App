class CheckBoxListModel{

  final String title;
  bool check = false;

  CheckBoxListModel(this.title,this.check);

}