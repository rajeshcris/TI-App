class station_inspection_registerModel {
  List<String> page = [];
  List<String> sList1 = [];
  List<bool> cList1 = [];
  String rmrks1 = "";

  station_inspection_registerModel(this.sList1, this.cList1, this.rmrks1);

  Map<String, dynamic> toJson() => {
        "paramList": [
          {"cList": cList1, "rmkrs": rmrks1}
        ]
      };
}
